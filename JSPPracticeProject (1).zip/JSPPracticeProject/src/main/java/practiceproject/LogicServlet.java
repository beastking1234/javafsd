package practiceproject;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LogicServlet
 */
@WebServlet("/LogicServlet")
public class LogicServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("product-name");
		int price = Integer.parseInt(request.getParameter("product-price"));
		int stock = Integer.parseInt(request.getParameter("product-stock"));
		
		Producti p1 = new Producti();
		p1.setProductName(name);
		p1.setProductPrice(price);
		p1.setProductStock(stock);
		HttpSession session = request.getSession();
		session.setAttribute("product", p1);
		
		RequestDispatcher rd = request.getRequestDispatcher("DisplayDetails.jsp");
		rd.forward(request, response);

	}

}
